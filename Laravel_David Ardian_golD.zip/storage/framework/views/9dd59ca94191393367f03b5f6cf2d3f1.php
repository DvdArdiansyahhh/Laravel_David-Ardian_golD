<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First view</title>
</head>
<body>
    Belajar Controller Laravel Mudah
</body>
</html><?php /**PATH D:\Kuliah\Semester 4\WS SI Web Framework\Project\Laravel_David Ardian_golD\resources\views/belajar.blade.php ENDPATH**/ ?>